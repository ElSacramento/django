from django.db import models
from question.models import Question, Answer, Tag
